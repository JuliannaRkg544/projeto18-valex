INSERT INTO companies ("id", "name", "apiKey") VALUES (1, 'Driven', 'zadKLNx.DzvOVjQH01TumGl2urPjPQSxUbf67vs0');
INSERT INTO employees ("id", "fullName", "cpf", "email", "companyId") VALUES (1, 'Fulano Rubens da Silva', '47100935741', 'fulano.silva@gmail.com', 1);
INSERT INTO employees ("id", "fullName", "cpf", "email", "companyId") VALUES (2,'Ciclana Maria Madeira', '08434681895', 'ciclaninha@gmail.com', 1);
INSERT INTO businesses ("id", "name", "type") VALUES (1, 'Responde Aí', 'education');
INSERT INTO businesses ("id", "name", "type") VALUES (2, 'Extra', 'groceries');
INSERT INTO businesses ("id", "name", "type") VALUES (3, 'Driven Eats', 'restaurant');
INSERT INTO businesses ("id", "name", "type") VALUES (4, 'Uber', 'transport');
INSERT INTO businesses ("id", "name", "type") VALUES (5, 'Unimed', 'health');